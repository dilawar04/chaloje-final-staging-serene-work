<?php

namespace App\Http\Controllers\Api;

use CodeDredd\Soap\Facades\Soap;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class FlightController extends Controller
{
    var $endpoints = ["airsial" => "http://demo.airsial.com.pk/starter/asmis/booking"];
    /**
     * Create a new controller instance.
     * @url https://laravel.com/docs/8.x/http-client
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    private function makeSession($api = 'airsial'){
        switch ($api){
            case 'airsial':
                $params = [["Caller" => "login", "Username" => "chalojeapi", 'Password' => '88A4S21ia2L']];
                $response = Http::withHeaders(['Content-Type' => 'application/json'])->post($this->endpoints['airsial'], $params);
                if($response->ok()){
                    $json = $response->json();
                    if($json['Success']){
                        return $json['Response']['Data'];
                    } else {
                        return $json;
                    }
                } else {
                    dd($response->serverError(), $response->clientError());
                }
            break;
            case 'serene':
                $endpoint = "https://srnappuat.radixxuat.com/SRN/Radixx.ConnectPoint/ConnectPoint.Security.svc";
                $params = ["Username" => "CHALOJE_ER_U", 'Password' => 'RGO$UAT!'];
                $response = Soap::baseWsdl($endpoint)
                    ->Submit_User($params);

                $response = Http::withHeaders(['Content-Type' => 'application/json'])->post($endpoint, $params);
                if($response->ok()){
                    $json = $response->json();
                    if($json['Success']){
                        return $json['Response']['Data'];
                    } else {
                        return $json;
                    }
                } else {
                    dd($response->serverError(), $response->clientError());
                }
                break;
        }
    }


    public function airport($IATA_code = '')
    {
        $rows = \App\Airport::where(['status' => 'Active'])->whereIn('IATA_code', explode(',', $IATA_code))->get(['id', 'IATA_code as iataname', 'city as name', 'airport']);
        return api_response($rows, 200);
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function cities($IATA_code = '')
    {
        if(empty($IATA_code)){
            $rows = \App\Airport::where(['status' => 'Active'])->get(['id', 'IATA_code as iataname', 'city as name', 'airport']);
            return api_response($rows, 200);
        }

        $params = [["Caller" => "sectors", "Departure" => $IATA_code]];
        $response = Http::withHeaders(['Content-Type' => 'application/json'])->post($this->endpoints['airsial'], $params);

        if($response->ok()){
            $json = $response->json();
            if($json['Success']){
                return api_response($json['Response']['Data'], 200);
            } else {
                return api_response($json, 200);
            }
        } else {
            dd($response->serverError(), $response->clientError());
        }
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getSingleFlight()
    {
        $_session = $this->makeSession('airsial');

        $params = [collect(["Caller" => "getSingleflight",
            "token" => $_session['token'],
            "DepartingOn" => "06-01-2021",
            "LocationDep" => "KHI",
            "LocationArr" => "ISB",
            "Return" => true,
            "ReturningOn" => "07-01-2021",
            "AdultNo" => 1,
            "ChildNo" => 0,
            "InfantNo" => 0
        ])->merge(\request()->input())->toArray()];
        $params[0]['Return'] = (\request('Return') == 'true');

        $response = Http::withHeaders(['Content-Type' => 'application/json'])->post($this->endpoints['airsial'], $params);

        if($response->ok()){
            $json = $response->json();
            if($json['Success']){
                return api_response($json['Response']['Data'], 200);
            } else {
                return api_response($json, 200);
            }
        } else {
            dd($response->serverError(), $response->clientError());
        }
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function bookSeat()
    {
        $_session = $this->makeSession('airsial');

        $params = [collect(["Caller" => "bookSeat",
            "token" => $_session['token'],
            "Return" => false,
            "DepartureJourney" => "180195",
            "DepartureFareType" => 2,
            "DepartureClass" => "1010",
            "DepartureFlight" => "PF121",
            "ReturningJourney" => "",
            "ReturningClass" => "",
            "ReturningFlight" => "",
            "ReturningFareType" => 1,
            "LocationDep" => "KHI",
            "LocationArr" => "ISB",
            "ftype" => "dom",
            "TotalSeats" => 1,
            "totalInfant" => 0,
            "totalAdult" => 1,
            "totalChild" => 0
        ])->merge(\request()->input())->toArray()];
        $params[0]['Return'] = (\request('Return') == 'true');

        $response = Http::withHeaders(['Content-Type' => 'application/json'])->post($this->endpoints['airsial'], $params);

        if($response->ok()){
            $json = $response->json();
            if($json['Success']){
                return api_response($json['Response']['Data'], 200);
            } else {
                return api_response($json, 200);
            }
        } else {
            dd($response->serverError(), $response->clientError());
        }
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function passengerInsertion()
    {
        $_session = $this->makeSession('airsial');

        $params = [collect(["Caller" => "passengerInsertion",
            "token" => $_session['token'],
            "PNR" => "1C2XSO",
            "adult" => [
                [
                    "Title" => "MR",
                    "WheelChair" => "N",
                    "FullName" => "SYED JAWWAD ALAM",
                    "Firstname" => "SYED JAWWAD",
                    "Lastname" => "ALAM"
                ]
            ],
            "child" => [
                [
                    "Title" => "MR",
                    "WheelChair" => "N",
                    "FullName" => "Child One",
                    "Firstname" => "Child",
                    "Lastname" => "One"
                ]
            ],
            "infant" => [
                [
                    "Title" => "MR",
                    "WheelChair" => "N",
                    "FullName" => "Infant One",
                    "Firstname" => "Infant",
                    "Lastname" => "One"
                ]
            ],

            "PrimaryCell" => "+92313-7559954",
            "SecondaryCell" => "+92",
            "EmailAddress" => "jawwad_alam2002@mail.com",
            "CNIC" => "",
            "Comments" => "",
            "ft" => "dom"
        ])->merge(\request()->input())->toArray()];

        $response = Http::withHeaders(['Content-Type' => 'application/json'])->post($this->endpoints['airsial'], $params);

        if($response->ok()){
            $json = $response->json();
            if($json['Success']){
                return api_response($json['Response']['Data'], 200);
            } else {
                return api_response($json, 200);
            }
        } else {
            dd($response->serverError(), $response->clientError());
        }
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function viewTicket($pnr)
    {
        $_session = $this->makeSession('airsial');

        $params = [collect(["Caller" => "viewTicket",
            "token" => $_session['token'],
            "PNR" => $pnr,
        ])->merge(\request()->input())->toArray()];

        $response = Http::withHeaders(['Content-Type' => 'application/json'])->post($this->endpoints['airsial'], $params);

        if($response->ok()){
            $json = $response->json();
            if($json['Success']){
                return api_response($json['Response']['Data'], 200);
            } else {
                return api_response($json, 200);
            }
        } else {
            dd($response->serverError(), $response->clientError());
        }
    }

}
